<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Untuk Kamu ❤️</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    font-family: "Segoe UI", sans-serif;
    background: linear-gradient(135deg, #ff758c, #ff7eb3);
    color: #333;
    overflow-x: hidden;
}

/* ==============================
   DATA YANG PERLU DIEDIT
   ==============================

   1. Nama pacar
   2. Nama kamu
   3. Tanggal jadian
   4. Foto
   5. Pesan permintaan maaf
   6. Nama file musik
*/

/* ==============================
   BACKGROUND
   ============================== */

.background-heart {
    position: fixed;
    bottom: -50px;
    font-size: 25px;
    animation: naik 8s linear infinite;
    opacity: 0.7;
    z-index: 0;
    pointer-events: none;
}

@keyframes naik {

    0% {
        transform: translateY(0) rotate(0deg);
        opacity: 0;
    }

    20% {
        opacity: 0.8;
    }

    100% {
        transform: translateY(-110vh) rotate(360deg);
        opacity: 0;
    }
}

/* ==============================
   OPENING
   ============================== */

#opening {
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    position: relative;
    z-index: 5;
}

.opening-content {
    color: white;
    padding: 30px;
}

.opening-content h1 {
    font-size: 35px;
    margin-bottom: 15px;
}

.opening-content p {
    font-size: 16px;
    margin-bottom: 30px;
}

/* Envelope */

.envelope {
    width: 180px;
    height: 120px;
    background: #fff;
    margin: 0 auto 30px;
    position: relative;
    cursor: pointer;
    border-radius: 8px;
    box-shadow: 0 15px 40px rgba(0,0,0,.25);
    transition: .4s;
}

.envelope:hover {
    transform: scale(1.08);
}

.envelope::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;

    width: 0;
    height: 0;

    border-left: 90px solid transparent;
    border-right: 90px solid transparent;
    border-top: 65px solid #ffb6c1;

    z-index: 2;
}

.envelope::after {
    content: "❤️";
    position: absolute;
    top: 43px;
    left: 70px;
    font-size: 40px;
    z-index: 5;
}

/* ==============================
   MAIN CONTENT
   ============================== */

#main {
    display: none;
    background: #fff7fa;
    min-height: 100vh;
    position: relative;
    z-index: 3;
}

/* Hero */

.hero {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    padding: 40px 20px;
}

.hero-content {
    max-width: 700px;
}

.hero-small {
    color: #e91e63;
    font-size: 17px;
    margin-bottom: 15px;
}

.hero h1 {
    font-size: clamp(38px, 8vw, 70px);
    color: #e91e63;
    margin-bottom: 15px;
}

.hero h2 {
    font-weight: 400;
    color: #555;
    margin-bottom: 20px;
}

.date {
    display: inline-block;
    padding: 10px 20px;
    border-radius: 30px;
    background: #ffe0ea;
    color: #e91e63;
    font-weight: bold;
}

/* ==============================
   PHOTO
   ============================== */

.photo-section {
    padding: 80px 20px;
    text-align: center;
}

.photo-section h2 {
    color: #e91e63;
    margin-bottom: 30px;
}

.photo-frame {
    width: min(90%, 420px);
    margin: auto;
    padding: 10px;
    background: white;
    border-radius: 20px;
    box-shadow: 0 15px 40px rgba(0,0,0,.15);
}

.photo-frame img {
    width: 100%;
    display: block;
    border-radius: 14px;
}

/* ==============================
   LETTER
   ============================== */

.letter-section {
    padding: 80px 20px;
    display: flex;
    justify-content: center;
}

.letter {
    width: min(90%, 700px);
    background: white;
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 15px 40px rgba(0,0,0,.12);
    line-height: 1.9;
}

.letter h2 {
    text-align: center;
    color: #e91e63;
    margin-bottom: 30px;
}

.letter p {
    margin-bottom: 18px;
}

.highlight {
    color: #e91e63;
    font-weight: bold;
}

/* ==============================
   BUTTON
   ============================== */

.button-area {
    text-align: center;
    padding: 50px 20px 100px;
}

.love-button {
    border: none;
    padding: 16px 35px;
    border-radius: 50px;
    background: linear-gradient(135deg, #e91e63, #ff4081);
    color: white;
    font-size: 17px;
    font-weight: bold;
    cursor: pointer;
    box-shadow: 0 10px 30px rgba(233,30,99,.3);
    transition: .3s;
}

.love-button:hover {
    transform: scale(1.08);
}

/* ==============================
   FINAL MESSAGE
   ============================== */

#finalMessage {
    display: none;
    text-align: center;
    padding: 60px 25px 120px;
    animation: muncul 1.5s ease;
}

#finalMessage h2 {
    color: #e91e63;
    font-size: 35px;
    margin-bottom: 20px;
}

#finalMessage p {
    max-width: 600px;
    margin: auto;
    line-height: 1.9;
}

@keyframes muncul {
    from {
        opacity: 0;
        transform: translateY(30px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* ==============================
   MUSIC BUTTON
   ============================== */

.music-button {
    position: fixed;
    right: 20px;
    bottom: 20px;
    width: 50px;
    height: 50px;
    border: none;
    border-radius: 50%;
    background: #e91e63;
    color: white;
    font-size: 22px;
    cursor: pointer;
    z-index: 999;
    box-shadow: 0 5px 20px rgba(0,0,0,.2);
}

/* ==============================
   MOBILE
   ============================== */

@media (max-width: 600px) {

    .opening-content h1 {
        font-size: 28px;
    }

    .hero h1 {
        font-size: 45px;
    }

    .letter {
        padding: 25px;
    }

    .photo-frame {
        width: 92%;
    }
}
</style>
</head>

<body>


<!-- =====================================================
     BACKGROUND HEARTS
     ===================================================== -->

<div class="background-heart" style="left:5%;animation-delay:0s;">❤️</div>
<div class="background-heart" style="left:15%;animation-delay:2s;">💕</div>
<div class="background-heart" style="left:30%;animation-delay:4s;">💗</div>
<div class="background-heart" style="left:50%;animation-delay:1s;">❤️</div>
<div class="background-heart" style="left:65%;animation-delay:3s;">💖</div>
<div class="background-heart" style="left:80%;animation-delay:5s;">💕</div>
<div class="background-heart" style="left:92%;animation-delay:2s;">❤️</div>


<!-- =====================================================
     OPENING
     ===================================================== -->

<section id="opening">

    <div class="opening-content">

        <div class="envelope" onclick="openLetter()"></div>

        <h1>Untuk Seseorang yang Aku Sayang ❤️</h1>

        <p>
            Ada sesuatu yang ingin aku sampaikan...
        </p>

        <p>
            <strong>Tekan amplopnya 💌</strong>
        </p>

    </div>

</section>


<!-- =====================================================
     MAIN WEBSITE
     ===================================================== -->

<main id="main">


    <!-- HERO -->

    <section class="hero">

        <div class="hero-content">

            <p class="hero-small">
                Untuk kamu, yang selalu ada di hatiku ❤️
            </p>

            <h1 id="namaPacar">
                Sayangg
            </h1>

            <h2>
                Scroll kebawah yaa ada yang mau aku bilang
            </h2>

            <div class="date">
                ❤️<span id="tanggalJadian">❤️</span>
            </div>

        </div>

    </section>


    <!-- PHOTO -->

    <section class="photo-section">

        <h2>
            Tentang Kita ❤️
        </h2>

        <div class="photo-frame">

            <!-- GANTI "foto-kita.jpg" DENGAN FOTO KALIAN -->

            <img
                src="Sayanggg.jpg"
                alt="Foto Kita"
            >

        </div>

    </section>


    <!-- LETTER -->

    <section class="letter-section">

        <div class="letter">

            <h2>
                Aku Minta Maaf 🥺
            </h2>

            <!--
            GANTI ISI PESAN DI BAWAH INI
            -->

            <p>
                Hai <span class="highlight" id="namaDalamPesan">
                    Sayang
                </span>...
            </p>

            <p>
                Aku mau meminta maaf atas semua kesalahan yang udah aku
                lakukan ke kamu.
            </p>

            <p>
                Aku sadar mungkin ada perkataan dan perbuatanku yang membuat
                kamu kecewa, sedih, atau bahkan terluka.
            </p>

            <p>
                Aku tidak ingin mencari alasan untuk membenarkan diriku.
                Aku hanya ingin mengakui bahwa aku salah dan aku benar-benar
                menyesal.
            </p>

            <p>
                Kamu adalah seseorang yang sangat berarti buat aku.
                Karena itu aku tidak ingin kesalahan yang aku lakukan
                membuat kita semakin jauh.
            </p>

            <p>
                Aku mungkin bukan pasangan yang sempurna.
                Aku masih banyak kekurangan dan masih harus banyak belajar.
            </p>

            <p>
                Tapi satu hal yang ingin kamu tahu...
                <span class="highlight">
                    aku benar-benar sayang sama kamu. ❤️
                </span>
            </p>

            <p>
                Aku akan berusaha memperbaiki kesalahanku,
                belajar dari semuanya, dan menjadi seseorang yang lebih baik
                untuk kamu.
            </p>

            <p>
                Kalau aku boleh meminta satu hal,
                aku ingin kamu memberikan aku kesempatan untuk memperbaiki
                semuanya.
            </p>

            <p>
                <strong>
                    Maafin aku ya, sayang. ❤️
                </strong>
            </p>

            <p style="text-align:right;">
                Dengan penuh cinta,<br>

                <span class="highlight" id="namaPengirim">
                    Aku
                </span>
            </p>

        </div>

    </section>


    <!-- BUTTON -->

    <section class="button-area">

        <p style="margin-bottom:20px;">
            Kalau kamu sudah selesai membaca...
        </p>

        <button
            class="love-button"
            onclick="forgiveMe()"
        >
            Aku Maafin Kamu ❤️
        </button>

    </section>


    <!-- FINAL -->

    <section id="finalMessage">

        <h2>
            Terima Kasih ❤️
        </h2>

        <p>
            Terima kasih karena sudah mau mendengarkan isi hatiku.
            Aku mungkin tidak sempurna, tapi aku akan selalu berusaha
            menjadi lebih baik untuk kamu.
            <br><br>

            Semoga kita bisa terus bersama,
            melewati hari-hari baik maupun buruk,
            dan membuat lebih banyak kenangan indah bersama.
            <br><br>

            <strong>
                Aku sayang kamu. ❤️
            </strong>
        </p>

    </section>


</main>


<!-- =====================================================
     MUSIC
     ===================================================== -->

<audio id="music" loop>

    <!--
    GANTI "musik.mp3" DENGAN FILE MUSIK KAMU

    Contoh:
    musik.mp3

    File musik harus berada di folder yang sama
    dengan index.html
    -->

    <source src="musik.mp3" type="audio/mpeg">

</audio>


<button
    class="music-button"
    onclick="toggleMusic()"
    id="musicButton"
>
    🎵
</button>


<script>

/* =====================================================
   DATA UTAMA
   EDIT BAGIAN INI
   ===================================================== */

const DATA = {

    // Nama pacar
    namaPacar: "Arista Ayu Vianni",

    // Nama kamu
    namaPengirim: "Rizky Yudi Pratama",

    // Tanggal jadian
    tanggalJadian: "19 Agustus 2026"

};


/* =====================================================
   MASUK KE WEBSITE
   ===================================================== */

function openLetter() {

    document.getElementById("opening").style.display = "none";

    document.getElementById("main").style.display = "block";

    // Isi data otomatis
    document.getElementById("namaPacar").innerText =
        DATA.namaPacar;

    document.getElementById("namaDalamPesan").innerText =
        DATA.namaPacar;

    document.getElementById("namaPengirim").innerText =
        DATA.namaPengirim;

    document.getElementById("tanggalJadian").innerText =
        DATA.tanggalJadian;

    // Mulai musik setelah user melakukan klik
    const music = document.getElementById("music");

    music.play().catch(() => {});

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

}


/* =====================================================
   MUSIK
   ===================================================== */

let musicPlaying = true;

function toggleMusic() {

    const music =
        document.getElementById("music");

    const button =
        document.getElementById("musicButton");

    if (music.paused) {

        music.play();

        button.innerText = "🎵";

        musicPlaying = true;

    } else {

        music.pause();

        button.innerText = "🔇";

        musicPlaying = false;

    }

}


/* =====================================================
   TOMBOL "AKU MAAFIN KAMU"
   ===================================================== */

function forgiveMe() {

    const finalMessage =
        document.getElementById("finalMessage");

    finalMessage.style.display = "block";

    // Scroll ke pesan terakhir
    setTimeout(() => {

        finalMessage.scrollIntoView({
            behavior: "smooth"
        });

    }, 300);


    // Ledakan hati
    createHearts();

}


/* =====================================================
   ANIMASI HATI
   ===================================================== */

function createHearts() {

    const emojis = [
        "❤️",
        "💕",
        "💗",
        "💖",
        "💓",
        "💘"
    ];

    for (let i = 0; i < 40; i++) {

        const heart =
            document.createElement("div");

        heart.innerText =
            emojis[
                Math.floor(
                    Math.random() * emojis.length
                )
            ];

        heart.style.position = "fixed";

        heart.style.left = "50%";

        heart.style.top = "50%";

        heart.style.fontSize =
            Math.random() * 25 + 15 + "px";

        heart.style.zIndex = "9999";

        heart.style.pointerEvents = "none";

        document.body.appendChild(heart);


        const angle =
            Math.random() * Math.PI * 2;

        const distance =
            Math.random() * 400 + 100;

        const x =
            Math.cos(angle) * distance;

        const y =
            Math.sin(angle) * distance;


        heart.animate(

            [

                {
                    transform:
                        "translate(-50%, -50%) scale(0)",
                    opacity: 1
                },

                {
                    transform:
                        `translate(
                            calc(-50% + ${x}px),
                            calc(-50% + ${y}px)
                        ) scale(1.5)`,
                    opacity: 0
                }

            ],

            {

                duration:
                    Math.random() * 1500 + 1000,

                easing:
                    "cubic-bezier(.17,.67,.83,.67)"

            }

        );


        setTimeout(() => {

            heart.remove();

        }, 2500);

    }

}

</script>

</body>
</html>